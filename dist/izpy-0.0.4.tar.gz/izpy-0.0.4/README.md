# izpy
AbstractTest class for generic calls in integration testing of API's
